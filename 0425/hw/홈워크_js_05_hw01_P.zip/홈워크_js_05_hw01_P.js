axios.(a)('https://api.example.com/data')
	.(b)(function (response) {
	console.log((c))
})