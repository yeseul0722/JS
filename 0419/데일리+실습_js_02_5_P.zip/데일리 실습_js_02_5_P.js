function findQueens(n) {
	// 이곳에 작성합니다.
	return answer
}

console.log(findQueens(4)) // 2